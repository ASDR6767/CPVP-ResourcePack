在聊天栏输入：/give @s minecraft:diamond_helmet[minecraft:item_model="netherite_ingot",minecraft:custom_model_data={strings:["hay_helmet"]},minecraft:equippable={slot:"head"}]

/give @s minecraft:diamond_helmet ←可以替换为任意物品